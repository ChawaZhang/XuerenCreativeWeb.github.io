# The Creative Web
Class repo for The Creative Web, Integrated Digital Media, Tandon School of Engineering, NYU

`3k6me5wkytc00000`

## Course details

[Class syllabus](https://docs.google.com/document/d/1I_do2mGcMNQ1Fl0hphzblNBm_zzNbAQlaoOaQCl4Thg/edit?usp=sharing)

[Office hours signup](https://calendar.google.com/calendar/selfsched?sstoken=UUhVYnEyYVU0aEVvfGRlZmF1bHR8ZTFjMTcyOWQxNjJjYzE0M2VkYTc2ZTMwMjViM2UxNTA)

## Class pages
- [Class 1](https://github.com/BarakChamo/The-Creative-Web/tree/master/classes/class%201)
- [Class 2](https://github.com/BarakChamo/The-Creative-Web/tree/master/classes/class%202)
- [Class 3](https://github.com/BarakChamo/The-Creative-Web/blob/master/classes/class%203)

## Help topics
- [How to use terminal](https://github.com/BarakChamo/The-Creative-Web/blob/master/help/Using%20Git.md)
- [How to use Git and GitHub](https://github.com/BarakChamo/The-Creative-Web/blob/master/help/Using%20Terminal.md)

## Resources
