## The Creative Web - Student presentations

Each week, one of you will give a presentation on the creative web.
<br>
You can choose a technology, a library, an inspiring project (maybe a project your made?)
<br>
or a part of the web you find exciting or want to change.

It's up to you! We want to hear what makes you excited about the web!

Please prepare a short presentation, no longer than 5-7 minutes, 
which you'll be asked to present on your assigned week.

### Presentation order
